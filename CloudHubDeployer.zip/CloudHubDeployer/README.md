# mule4deploy
This is a mule 4 application to deploy with CloudHub via Jenkins Pipeline
